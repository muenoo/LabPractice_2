import numpy as np
from PIL import Image
from pathlib import Path
import torch
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from torchvision import transforms
import os
import glob

import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F



dir_path = './images/train'

class MyDataset(torch.utils.data.Dataset):

    def __init__(self, dir_path,transform=None):
        
        super().__init__()
        
        self.dir_path = dir_path
        self.transform = transform
        self.image_paths = [str(p) for p in Path(self.dir_path).glob("**/*.png")]
        self.len = len(self.image_paths)
        
    def __len__(self):
        return self.len
    
    def __getitem__(self, index):
        p = self.image_paths[index]

        image = Image.open(p)
        image = image.convert("RGB")
        image = self.transform(image)  

        
        # ラベル (「1」: 1, 「2」: 2)
        label = p.split("\\")[2]
        label = 1 if label == "2" else 2
        
        return image, label
    
transform = transforms.Compose([transforms.ToTensor(), 
                                  transforms.Resize(size=(64, 64)),
                              transforms.Normalize(
                                  [0.5, 0.5, 0.5],  
                                  [0.5, 0.5, 0.5], 
                               )]) 


dataset = MyDataset(dir_path,transform)

train_dataset, val_dataset = torch.utils.data.random_split(dataset=dataset, lengths=[24, 8], generator=torch.Generator().manual_seed(42))

train_dataloader = DataLoader(
    train_dataset, batch_size=2, shuffle=True,
     drop_last=True
)

val_dataloader = DataLoader(
    val_dataset, batch_size=2, shuffle=False,
     drop_last=True
)

dataloaders_dict = {
    'train': train_dataloader, 
    'valid': val_dataloader
}

class Net(nn.Module):
    def __init__(self):
        
        super(Net, self).__init__()
        self.conv1_1 = nn.Conv2d(in_channels=3, out_channels=64, kernel_size=3, padding=1)
        self.conv1_2 = nn.Conv2d(in_channels=64, out_channels=64, kernel_size=3, padding=1)
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)

        self.conv2_1 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, padding=1)
        self.conv2_2 = nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, padding=1)
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.fc1 = nn.Linear(in_features=32* 32 * 32, out_features=128)
        self.fc2 = nn.Linear(in_features=128, out_features=10)

    def forward(self, x):
        x = F.relu(self.conv1_1(x))
        x = F.relu(self.conv1_2(x))
        x = self.pool1(x)

        x = F.relu(self.conv2_1(x))
        x = F.relu(self.conv2_2(x))
        x = self.pool2(x)

        x = x.view(-1, 32 * 32 * 32)
        x = self.fc1(x)
        x = F.relu(x)
        x = self.fc2(x)
        x = F.softmax(x, dim=1)
        return x

net = Net()


criterion = nn.CrossEntropyLoss()

optimizer = optim.SGD(net.parameters(), lr=0.01)

nll_loss = nn.NLLLoss()


# エポック数

num_epochs = 10

for epoch in range(num_epochs):

    print('Epoch {}/{}'.format(epoch+1, num_epochs))
    print('-------------')

    for phase in ['train', 'valid']:

        if phase == 'train':
            # モデルを訓練モードに設定
            net.train()
        else:
            # モデルを推論モードに設定
            net.eval()

        # 損失和

        epoch_loss = 0.0

        # 正解数

        epoch_corrects = 0

        # DataLoaderからデータをバッチごとに取り出す
        for inputs, labels in dataloaders_dict[phase]:
            
 
            # optimizerの初期化
            optimizer.zero_grad()

            # 学習時のみ勾配を計算させる設定にする
            with torch.set_grad_enabled(phase == 'train'):

                 outputs = net(inputs)

                 # 損失を計算
                 loss = criterion(outputs, labels)
                
                 # ラベルを予測
                 _, preds = torch.max(outputs, 1)
                
                 # 訓練時はバックプロパゲーション
                 if phase == 'train':

                     # 逆伝搬の計算
                     loss.backward()
                     # パラメータの更新
                     optimizer.step()
                
                # イテレーション結果の計算
                # lossの合計を更新
                # PyTorchの仕様上各バッチ内での平均のlossが計算される。
                # データ数を掛けることで平均から合計に変換をしている。
                # 損失和は「全データの損失/データ数」で計算されるため、
                

                # 平均のままだと損失和を求めることができないため。
            epoch_loss += loss.item() * inputs.size(0)
                
                # 正解数の合計を更新
            epoch_corrects += torch.sum(preds == labels.data)

        # epochごとのlossと正解率を表示

        epoch_loss = epoch_loss / len(dataloaders_dict[phase].dataset)
        epoch_acc = epoch_corrects.double() / len(dataloaders_dict[phase].dataset)

        print('{} Loss: {:.4f} Acc: {:.4f}'.format(phase, epoch_loss, epoch_acc))



 
