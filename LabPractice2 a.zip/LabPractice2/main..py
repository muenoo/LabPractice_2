import classify.controller.do as do
do.image_classification_ONE_or_TWO()